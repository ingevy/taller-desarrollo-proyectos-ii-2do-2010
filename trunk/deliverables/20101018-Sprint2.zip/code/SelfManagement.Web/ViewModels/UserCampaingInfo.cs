﻿namespace CallCenter.SelfManagement.Web.ViewModels
{
    public struct UserCampaingInfo
    {
        public int Id { get; set; }

        public string DisplayName { get; set; }
    }
}