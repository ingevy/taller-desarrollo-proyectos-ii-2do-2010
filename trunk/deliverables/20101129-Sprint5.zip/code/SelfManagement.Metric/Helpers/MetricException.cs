﻿namespace CallCenter.SelfManagement.Metric.Helpers
{
    public class MetricException : System.ApplicationException
    {
        public MetricException(string message)
            : base(message)
        {
        }
    }
}