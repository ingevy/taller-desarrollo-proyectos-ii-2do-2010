﻿namespace CallCenter.SelfManagement.Web.ViewModels
{
    public enum MetricLevel
    {
        Optimal,
        Objective,
        Minimum,
        Unsatisfactory
    }
}
