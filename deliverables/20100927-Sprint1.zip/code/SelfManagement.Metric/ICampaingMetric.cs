﻿namespace CallCenter.SelfManagement.Metric
{
    public interface ICampaingMetric
    {
    }
}
