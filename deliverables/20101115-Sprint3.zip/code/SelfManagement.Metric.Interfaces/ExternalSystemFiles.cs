﻿namespace CallCenter.SelfManagement.Metric.Interfaces
{
    public enum ExternalSystemFiles
    {
        SUMMARY,
        QA,
        TTS,
        STS,
        HF
    }
}
